LIBRARY MANAGEMENT - ANDROID STUDIO PROJECT

Project name: LibraryManagement
Package: com.example.library
Language: Java
Minimum Android version: Android 6.0 (API 23)

HOW TO OPEN
1. Extract this ZIP file.
2. Open Android Studio.
3. Select File > Open.
4. Select the extracted LibraryManagement folder (the folder containing settings.gradle).
5. Allow Gradle sync and wait for it to finish.
6. Connect your Android phone with USB debugging enabled, or select an emulator.
7. Press the green Run button.

FEATURES
- Add a library record
- View all records
- Update a record using Student ID
- Delete a record using Student ID
- Records are stored locally using SQLite

NOTE
This project uses Android Gradle Plugin 8.7.3 and compile SDK 35.
Android Studio may download Gradle and Android SDK components during the first sync.

RUN USING runapp.bat
1. Extract the ZIP file.
2. Double-click runapp.bat.
3. If Gradle is installed and available in PATH, it tries to build and install the app.
4. Otherwise, it opens the project in Android Studio (if found). Wait for Gradle Sync, connect a device or start an emulator, then press Run.
