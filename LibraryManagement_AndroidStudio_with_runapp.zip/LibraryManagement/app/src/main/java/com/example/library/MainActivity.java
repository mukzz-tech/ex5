package com.example.library;

import android.app.Activity;
import android.os.Bundle;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    EditText id, name, book, date;
    TextView result;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        id = findViewById(R.id.id);
        name = findViewById(R.id.name);
        book = findViewById(R.id.book);
        date = findViewById(R.id.date);
        result = findViewById(R.id.result);

        DBHelper helper = new DBHelper();
        db = helper.getWritableDatabase();

        Button add = findViewById(R.id.add);
        Button view = findViewById(R.id.view);
        Button update = findViewById(R.id.update);
        Button delete = findViewById(R.id.delete);

        add.setOnClickListener(v -> addRecord());
        view.setOnClickListener(v -> viewRecords());
        update.setOnClickListener(v -> updateRecord());
        delete.setOnClickListener(v -> deleteRecord());
    }

    private void addRecord() {
        if (!inputsValid()) return;

        ContentValues values = new ContentValues();
        values.put("id", id.getText().toString().trim());
        values.put("name", name.getText().toString().trim());
        values.put("book", book.getText().toString().trim());
        values.put("date", date.getText().toString().trim());

        long row = db.insert("Library", null, values);
        if (row == -1) {
            Toast.makeText(this, "Book record could not be added. Check the ID.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Record Added", Toast.LENGTH_SHORT).show();
            clearFields();
            viewRecords();
        }
    }

    private void viewRecords() {
        Cursor cursor = db.rawQuery("SELECT * FROM Library ORDER BY id", null);
        StringBuilder data = new StringBuilder();

        if (cursor.moveToFirst()) {
            do {
                data.append("Student ID: ").append(cursor.getString(0)).append("\n");
                data.append("Student Name: ").append(cursor.getString(1)).append("\n");
                data.append("Book Title: ").append(cursor.getString(2)).append("\n");
                data.append("Issue Date: ").append(cursor.getString(3)).append("\n\n");
            } while (cursor.moveToNext());
        } else {
            data.append("No records found.");
        }

        cursor.close();
        result.setText(data.toString());
    }

    private void updateRecord() {
        String recordId = id.getText().toString().trim();
        if (recordId.isEmpty()) {
            Toast.makeText(this, "Enter Student ID to update", Toast.LENGTH_SHORT).show();
            return;
        }
        if (name.getText().toString().trim().isEmpty()
                || book.getText().toString().trim().isEmpty()
                || date.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Fill all fields to update", Toast.LENGTH_SHORT).show();
            return;
        }

        ContentValues values = new ContentValues();
        values.put("name", name.getText().toString().trim());
        values.put("book", book.getText().toString().trim());
        values.put("date", date.getText().toString().trim());

        int rows = db.update("Library", values, "id=?", new String[]{recordId});
        Toast.makeText(this, rows > 0 ? "Record Updated" : "ID not found", Toast.LENGTH_SHORT).show();
        viewRecords();
    }

    private void deleteRecord() {
        String recordId = id.getText().toString().trim();
        if (recordId.isEmpty()) {
            Toast.makeText(this, "Enter Student ID to delete", Toast.LENGTH_SHORT).show();
            return;
        }

        int rows = db.delete("Library", "id=?", new String[]{recordId});
        Toast.makeText(this, rows > 0 ? "Record Deleted" : "ID not found", Toast.LENGTH_SHORT).show();
        clearFields();
        viewRecords();
    }

    private boolean inputsValid() {
        if (id.getText().toString().trim().isEmpty()
                || name.getText().toString().trim().isEmpty()
                || book.getText().toString().trim().isEmpty()
                || date.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void clearFields() {
        id.setText("");
        name.setText("");
        book.setText("");
        date.setText("");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (db != null && db.isOpen()) db.close();
    }

    private class DBHelper extends SQLiteOpenHelper {
        DBHelper() {
            super(MainActivity.this, "LibraryDB", null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase database) {
            database.execSQL("CREATE TABLE Library (" +
                    "id TEXT PRIMARY KEY, " +
                    "name TEXT, " +
                    "book TEXT, " +
                    "date TEXT)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
            database.execSQL("DROP TABLE IF EXISTS Library");
            onCreate(database);
        }
    }
}
