@echo off
setlocal
 title Library Management - Android App
set "PROJECT_DIR=%~dp0"
echo ============================================
echo   Library Management - Android Studio
echo ============================================
echo.

REM If Gradle is installed and available in PATH, build and install the app.
where gradle >nul 2>nul
if %errorlevel%==0 (
    echo Building and installing the app...
    cd /d "%PROJECT_DIR%"
    gradle installDebug
    if errorlevel 1 (
        echo.
        echo Build/install failed. Open this folder in Android Studio and check Gradle sync.
        pause
        exit /b 1
    )
    echo.
    echo Finished. If a device is connected with USB debugging enabled, the app was installed.
    pause
    exit /b 0
)

REM Otherwise open the project in Android Studio, if it is installed in a common location.
if exist "%LOCALAPPDATA%\Programs\Android Studio\bin\studio64.exe" (
    start "" "%LOCALAPPDATA%\Programs\Android Studio\bin\studio64.exe" "%PROJECT_DIR%"
    exit /b 0
)
if exist "%ProgramFiles%\Android\Android Studio\bin\studio64.exe" (
    start "" "%ProgramFiles%\Android\Android Studio\bin\studio64.exe" "%PROJECT_DIR%"
    exit /b 0
)
if exist "%ProgramFiles(x86)%\Android\Android Studio\bin\studio64.exe" (
    start "" "%ProgramFiles(x86)%\Android\Android Studio\bin\studio64.exe" "%PROJECT_DIR%"
    exit /b 0
)

 echo Android Studio was not found automatically.
echo Please open Android Studio, choose File ^> Open, and select:
echo %PROJECT_DIR%
echo Then wait for Gradle Sync and press the green Run button.
pause
